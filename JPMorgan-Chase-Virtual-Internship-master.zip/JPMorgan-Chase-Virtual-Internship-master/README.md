# JPMorgan-Chase-Virtual-Internship

This repository contains the submitted patch files of the various tasks assigned by JPMorgan Chase &amp; Co. Software Engineering Virtual Internship

## Website Link:

[https://www.insidesherpa.com/virtual-internships/R5iK7HMxJGBgaSbvk](https://www.insidesherpa.com/virtual-internships/R5iK7HMxJGBgaSbvk)

## My Certificate of Completion 

![](https://github.com/chandrikadeb7/JPMorgan-Chase-Virtual-Internship/blob/master/Screen%20Shot%202020-05-11%20at%2012.41.54%20PM.png)

## For any queries/doubts:

:envelope: chandrikadeb7@gmail.com :thumbsup:
